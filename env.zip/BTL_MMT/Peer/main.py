import Server

def main():   
    Server.start()

if __name__ == "__main__":
    main()